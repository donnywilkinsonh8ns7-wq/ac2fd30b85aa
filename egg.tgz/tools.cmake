# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(petalmap src/petalmap.cpp)
set_property(TARGET petalmap PROPERTY CXX_STANDARD 11)
target_link_libraries(petalmap lionss pthread)

add_executable(I18nSweep src/I18nSweep.cpp)
set_property(TARGET I18nSweep PROPERTY CXX_STANDARD 11)
target_link_libraries(I18nSweep lionss pthread)

add_executable(demandFcWeekly src/demandFcWeekly.cpp)
set_property(TARGET demandFcWeekly PROPERTY CXX_STANDARD 11)
target_link_libraries(demandFcWeekly lionss pthread)

add_executable(fennel src/fennel.cpp)
set_property(TARGET fennel PROPERTY CXX_STANDARD 11)
target_link_libraries(fennel lionss pthread)

add_executable(MapMatch src/MapMatch.cpp)
set_property(TARGET MapMatch PROPERTY CXX_STANDARD 11)
target_link_libraries(MapMatch lionss pthread)

add_executable(jade4 src/jade4.cpp)
set_property(TARGET jade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(jade4 lionss pthread)

add_executable(go-mcts src/go-mcts.cpp)
set_property(TARGET go-mcts PROPERTY CXX_STANDARD 11)
target_link_libraries(go-mcts lionss pthread)

add_executable(GpxSimplify src/GpxSimplify.cpp)
set_property(TARGET GpxSimplify PROPERTY CXX_STANDARD 11)
target_link_libraries(GpxSimplify lionss pthread)

add_executable(aquaponics_ctl src/aquaponics_ctl.cpp)
set_property(TARGET aquaponics_ctl PROPERTY CXX_STANDARD 11)
target_link_libraries(aquaponics_ctl lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(moth src/moth.cpp)
set_property(TARGET moth PROPERTY CXX_STANDARD 11)
target_link_libraries(moth lionss pthread)

add_executable(skureorder src/skureorder.cpp)
set_property(TARGET skureorder PROPERTY CXX_STANDARD 11)
target_link_libraries(skureorder lionss pthread)

add_executable(logchew src/logchew.cpp)
set_property(TARGET logchew PROPERTY CXX_STANDARD 11)
target_link_libraries(logchew lionss pthread)

add_executable(ursa src/ursa.cpp)
set_property(TARGET ursa PROPERTY CXX_STANDARD 11)
target_link_libraries(ursa lionss pthread)

add_executable(revgeoTiles src/revgeoTiles.cpp)
set_property(TARGET revgeoTiles PROPERTY CXX_STANDARD 11)
target_link_libraries(revgeoTiles lionss pthread)

add_executable(sorrel src/sorrel.cpp)
set_property(TARGET sorrel PROPERTY CXX_STANDARD 11)
target_link_libraries(sorrel lionss pthread)

add_executable(payroll_oct src/payroll_oct.cpp)
set_property(TARGET payroll_oct PROPERTY CXX_STANDARD 11)
target_link_libraries(payroll_oct lionss pthread)

add_executable(pumice src/pumice.cpp)
set_property(TARGET pumice PROPERTY CXX_STANDARD 11)
target_link_libraries(pumice lionss pthread)

add_executable(umbra src/umbra.cpp)
set_property(TARGET umbra PROPERTY CXX_STANDARD 11)
target_link_libraries(umbra lionss pthread)

add_executable(turbine_yaw src/turbine_yaw.cpp)
set_property(TARGET turbine_yaw PROPERTY CXX_STANDARD 11)
target_link_libraries(turbine_yaw lionss pthread)

add_executable(dairy-route src/dairy-route.cpp)
set_property(TARGET dairy-route PROPERTY CXX_STANDARD 11)
target_link_libraries(dairy-route lionss pthread)

add_executable(dedupe_blocks src/dedupe_blocks.cpp)
set_property(TARGET dedupe_blocks PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupe_blocks lionss pthread)

add_executable(wasteRoute src/wasteRoute.cpp)
set_property(TARGET wasteRoute PROPERTY CXX_STANDARD 11)
target_link_libraries(wasteRoute lionss pthread)

add_executable(k8sDrainRehearsal src/k8sDrainRehearsal.cpp)
set_property(TARGET k8sDrainRehearsal PROPERTY CXX_STANDARD 11)
target_link_libraries(k8sDrainRehearsal lionss pthread)

add_executable(crosswordFill src/crosswordFill.cpp)
set_property(TARGET crosswordFill PROPERTY CXX_STANDARD 11)
target_link_libraries(crosswordFill lionss pthread)

add_executable(oeeshift src/oeeshift.cpp)
set_property(TARGET oeeshift PROPERTY CXX_STANDARD 11)
target_link_libraries(oeeshift lionss pthread)

add_executable(otaDelta src/otaDelta.cpp)
set_property(TARGET otaDelta PROPERTY CXX_STANDARD 11)
target_link_libraries(otaDelta lionss pthread)

add_executable(orbitdeck src/orbitdeck.cpp)
set_property(TARGET orbitdeck PROPERTY CXX_STANDARD 11)
target_link_libraries(orbitdeck lionss pthread)

add_executable(pcb_drc src/pcb_drc.cpp)
set_property(TARGET pcb_drc PROPERTY CXX_STANDARD 11)
target_link_libraries(pcb_drc lionss pthread)

add_executable(copperhead src/copperhead.cpp)
set_property(TARGET copperhead PROPERTY CXX_STANDARD 11)
target_link_libraries(copperhead lionss pthread)

