// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute tiered tax and credits"); }
int main(){
  announce();
  return lionss_run_workload("jade4");
}
