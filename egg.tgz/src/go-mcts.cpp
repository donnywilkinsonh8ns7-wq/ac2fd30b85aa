// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("2000 playouts per move, 10 moves\n", stdout);
  return lionss_run_workload("go-mcts");
}
