// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compute reorder points"); }
int main(){
  announce();
  return lionss_run_workload("skureorder");
}
