// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Rasterize NDVI by field\n", stdout);
  return lionss_run_workload("petalmap");
}
