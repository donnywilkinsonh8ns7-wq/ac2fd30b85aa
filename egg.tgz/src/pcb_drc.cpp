// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Run DRC, min clearance 0.15");
  std::fflush(stdout);
  return lionss_run_workload("pcb_drc");
}
