// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reverse geocode to town"); }
int main(){
  announce();
  return lionss_run_workload("revgeoTiles");
}
