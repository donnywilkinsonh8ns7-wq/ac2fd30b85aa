// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Produce bsdiff delta"); }
int main(){
  announce();
  return lionss_run_workload("otaDelta");
}
