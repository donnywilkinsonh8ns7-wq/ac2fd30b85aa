// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("OCR the scanned page\n", stdout);
  return lionss_run_workload("umbra");
}
