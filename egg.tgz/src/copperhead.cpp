// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Count groups per rotation"); }
int main(){
  announce();
  return lionss_run_workload("copperhead");
}
