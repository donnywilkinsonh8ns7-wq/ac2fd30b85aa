// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Content-defined chunking\n", stdout);
  return lionss_run_workload("dedupe_blocks");
}
